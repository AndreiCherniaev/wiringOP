#define VERSION "0.1"
#define VERSION_MAJOR 0
#define VERSION_MINOR 1

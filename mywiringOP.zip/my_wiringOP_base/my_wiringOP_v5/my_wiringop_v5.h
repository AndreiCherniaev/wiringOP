#ifndef MY_WIRINGOP_V5_H
#define MY_WIRINGOP_V5_H

class My_wiringOP_v5
{
public:
    My_wiringOP_v5();
};

#endif // MY_WIRINGOP_V5_H
